//
//  mainView.swift
//  Terserah
//
//  Created by Adriel Bernard Rusli on 06/04/23.
//

import SwiftUI

struct MainView: View {
    class Food: Identifiable {
        var id = UUID()
        var name: String
        var description: String
        var imageName: String
        
        init(name: String, description: String, imageName: String) {
            self.name = name
            self.description = description
            self.imageName = imageName
        }
    }
    
    var foods = [
        Food(name: "Pizza", description: "Pizza is an Italian dish consisting of a flat dough topped with tomato sauce, cheese, and various toppings, usually baked in an oven and served as a meal or snack.", imageName: "pizza"),
        Food(name: "Indonesian Fried Chicken", description: "Indonesian fried chicken, known as ayam goreng, is a dish made by marinating chicken pieces in spices and deep-frying until crispy, often served with rice and sambal.", imageName: "ayam"),
        Food(name: "Meatballs", description: "Bakso is an Indonesian meatball soup made from ground meat, typically beef, served in a savory broth with noodles, vegetables, and tofu.", imageName: "bakso"),
        Food(name: "Ice Cream", description: "Ice cream is a frozen dessert made from milk, cream, sugar, and flavorings, often enjoyed on its own or used as a topping for other desserts.", imageName: "eskrim"),
        Food(name: "Sunny Side Up", description: "Sunny side up is a way of cooking eggs where the yolk remains runny and the white is fully cooked, often served as a breakfast food.", imageName: "telor"),
        Food(name: "Satay", description: "Satay is a Southeast Asian dish consisting of grilled skewered meat served with a peanut sauce and sometimes rice or vegetables.", imageName: "sate"),
        Food(name: "Burger", description: "A burger is a sandwich made with a cooked ground meat patty, typically beef, served on a bun with various toppings and condiments, often enjoyed as a fast food item.", imageName: "burger"),
        Food(name: "Donut", description: "A donut is a small, sweet, ring-shaped pastry made from fried dough that can be coated with glaze or icing and filled with cream or other sweet fillings.", imageName: "donut"),
        Food(name: "Steak", description: "Steak is a cut of meat, typically beef, that is cooked by grilling, broiling, or pan-searing and is often served with a variety of side dishes such as vegetables, potatoes, or salad.", imageName: "steak"),
        Food(name: "French Fries", description: "Fries, also known as French fries or chips, are a popular side dish made from sliced and deep-fried potatoes, often served with a variety of condiments or toppings.", imageName: "fries"),
        Food(name: "Cheese Cake", description: "Cheesecake is a dessert made from a mixture of soft, fresh cheese, eggs, sugar, and a crust made from crushed cookies or graham crackers, often served with a fruit topping or whipped cream.", imageName: "cheesecake"),
        Food(name: "Ebi Furai", description: "Ebi furai is a Japanese dish made by deep-frying breaded and seasoned prawns, often served with tonkatsu sauce or a mayonnaise-based dipping sauce.", imageName: "ebi"),
        Food(name: "Fried Kwetiau", description: "Fried kwetiau is a popular Indonesian dish made from stir-fried flat rice noodles with meat, vegetables, and seasonings, often served as a street food or at local restaurants.", imageName: "kwetiaugoreng"),
        Food(name: "Fried Rice", description: "Fried rice is a dish made from cooked rice that is stir-fried with various ingredients such as eggs, vegetables, meats, and seasonings, often served as a side dish or as a main course.", imageName: "nasigoreng"),
        Food(name: "Indonesian Yellow Rice", description: "Indonesian yellow rice, or nasi kuning, is a fragrant and flavorful rice dish made with turmeric, coconut milk, and spices, often served with a variety of side dishes and enjoyed as a staple food for special occasions.", imageName: "nasikuning")
    ]
    
    @State private var selectedFoodItem: Food?
    
    var body: some View {
        NavigationView{
            ZStack{
                Image("Background1")
                    .resizable()
                    .scaledToFill()
                    .ignoresSafeArea()
                
                GeometryReader{ geometry in
                    
                    VStack {
                        Button(action: {
                            selectedFoodItem = foods.randomElement()
                        }) {
                            Image("Button 1")
                                .shadow(color: Color.yellow, radius: 4)
                            
                            
                        }.position(x : geometry.size.width/2, y: geometry.size.height * 0.37)
                            .sheet(item: $selectedFoodItem) { food in
                                DetailView(viewModel: DetailViewModel(food: food))
                            }
                    }
                }
            }
            
        }.navigationViewStyle(.stack)
            .navigationBarBackButtonHidden(true)
        
    }
}

struct DetailView: View {
    @ObservedObject var viewModel: DetailViewModel
    
    var body: some View {
        
        if let food = viewModel.food {
            ZStack{
                Image("backgroundreveal")
                    .resizable()
                    .ignoresSafeArea()
                GeometryReader{ geometry in
                    VStack{
                        VStack{
                            LottieView(name : food.imageName)
                                .scaleEffect(1.3)
                        }.frame(width: 400 , height: 300)
                            .position(x : geometry.size.width/2 , y : geometry.size.height * 0.45)
                        VStack{
                            Text(food.name)
                                .font(.system(size: 50))
                                .foregroundColor(.white)
                            
                            
                        }.frame(width: 450 , height: 75)
                            .position(x : geometry.size.width/2 , y: geometry.size.height * 0.38)
                        VStack{
                            Text(food.description)
                                .frame(width: 350)
                                .fixedSize(horizontal: false, vertical: true)
                                .foregroundColor(.white)
                        }.frame(width: 450 , height: 200)
                            .position(x : geometry.size.width/2 , y : geometry.size.height * 0.19)
                    }
                }
            }
        } else {
            VStack {
                Text("No data available")
            }
        }
    }
}

class DetailViewModel: ObservableObject {
    @Published var food: MainView.Food?
    init(food: MainView.Food?) {
        self.food = food
    }
}



struct MainView_Previews: PreviewProvider {
    static var previews: some View {
        MainView()
    }
}


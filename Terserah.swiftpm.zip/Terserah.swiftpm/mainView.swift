//
//  mainView.swift
//  Terserah
//
//  Created by Adriel Bernard Rusli on 06/04/23.
//

import SwiftUI

struct mainView: View {
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        ZStack{
            
        }
    }
}

struct mainView_Previews: PreviewProvider {
    static var previews: some View {
        mainView()
    }
}

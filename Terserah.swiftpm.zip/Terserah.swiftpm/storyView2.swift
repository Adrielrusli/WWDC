//
//  storyView2.swift
//  Terserah
//
//  Created by Adriel Bernard Rusli on 19/04/23.
//

import SwiftUI

struct storyView2: View {
    
    @State private var showImage1 = false
    @State private var showImage2 = false
    @State private var showImage3 = false
    
    var body: some View {
        
        NavigationView{
            
            ZStack{
                
                GeometryReader{ geometry in
                    NavigationLink(destination: MainView()){
                        Text("Skip")
                    }
                    .position(x : geometry.size.width * 0.87 , y: geometry.size.height * 0.05)
                    
                    VStack{
                        
                        HStack {
                            if showImage1 {
                                Image("4")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 450 , height: 300)
                                    .shadow(radius: 4)
                                    .offset(x: -geometry.size.width * 0.17 , y: -geometry.size.width * 0.1)
                                    .transition(.slide)
                                    .animation(.easeIn(duration: 1.0))
                            }
                        }
                        .onAppear {
                            Timer.scheduledTimer(withTimeInterval: 2.0, repeats: false) { _ in
                                withAnimation {
                                    showImage1 = true
                                }
                            }
                        }
                        
                        HStack {
                            if showImage2 {
                                Image("5")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 450 , height: 300)
                                    .shadow(radius: 4)
                                    .offset(x: geometry.size.width * 0.17 , y:  -geometry.size.height * 0.05)
                                    .transition(.slide)
                                    .animation(.easeIn(duration: 1.0))
                            }
                        }
                        .onAppear {
                            Timer.scheduledTimer(withTimeInterval: 4.0, repeats: false) { _ in
                                withAnimation {
                                    showImage1 = true
                                    showImage2 = true
                                }
                            }
                        }
                        
                        HStack {
                            if showImage3 {
                                
                                Image("6")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 450 , height: 300)
                                    .shadow(radius: 4)
                                    .offset(x: -geometry.size.width * 0.17, y: -geometry.size.height * 0.03)
                                    .transition(.slide)
                                    .animation(.easeIn(duration: 1.0))
                            }
                        }
                        .onAppear {
                            Timer.scheduledTimer(withTimeInterval: 6.0, repeats: false) { _ in
                                withAnimation {
                                    showImage1 = true
                                    showImage2 = true
                                    showImage3 = true
                                }
                            }
                        }
                        
                    }
                    .frame(width: geometry.size.width * 0.9 , height: geometry.size.height * 0.95)
                    .position(x : geometry.size.width * 0.5 , y: geometry.size.height * 0.5)
                    if showImage1 && showImage2 && showImage3{
                        NavigationLink(destination: storyView3()){
                            RoundedRectangle(cornerRadius: 5)
                                .frame(width: geometry.size.width * 0.3 , height: geometry.size.height * 0.05)
                                .overlay(Text("Next")
                                    .foregroundColor(.white)
                                )
                                .foregroundColor(.black)
                            
                        }.position(x: geometry.size.width * 0.5, y: geometry.size.height * 0.95)
                    }
                }
                
            }.background(Color("bgcolor"))
                .edgesIgnoringSafeArea(.all)
            
        }.navigationViewStyle(.stack)
            .navigationBarBackButtonHidden(true)
    }
}

struct storyView2_Previews: PreviewProvider {
    static var previews: some View {
        storyView2()
    }
}
